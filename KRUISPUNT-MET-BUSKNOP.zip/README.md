# KRUISPUNT-MET-BUSKNOP
Kruispunt regeling, met een knop bij de hoofdstraat voor voorrang aan te vragen.
